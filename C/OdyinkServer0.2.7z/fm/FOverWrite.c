#include <stdio.h>

void FOverWrite(char *fPath,char *text)
{
	FILE *fp = NULL;
	fp = fopen(fPath,"w+");
	fputs(text,fp);
	fclose(fp);
}
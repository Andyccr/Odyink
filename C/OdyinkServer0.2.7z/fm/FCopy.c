#include <stdio.h> 

int FCopy (char *source,char *target)
{
	char tfs; // Temp file stream
	int n;
	//
	FILE *fpSource;
	fpSource = fopen(source,"rb");
	//
	FILE *fpTarget;
		fpTarget = fopen(target,"wb+");
	// if use the feof() it will write the last byte again
	while (fread(&tfs,1,1,fpSource))
		fwrite(&tfs,1,1,fpTarget);
	printf("Finish\n");
	//
	fclose(fpTarget);
	fclose(fpSource);
	return 0;
}

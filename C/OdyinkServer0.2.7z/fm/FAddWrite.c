#include <stdio.h>

void FAddWrite(char *fPath,char *text)
{
	FILE *fp = NULL;
	fp = fopen(fPath,"a+");
	fputs((char *)text,fp);
	fclose(fp);
}
#include <stdio.h>
#include "../include/def.h"

int ReadNum(char *fPath)
{
	int i;
	char chnum[7];
	FILE *fp = NULL;
	fp = fopen(fPath, "r");
	if (!(fp == NULL))
	{
		// Please viev the Dev Document
		/* Expr2 will set last element = EOF
		So I should deal with it*/
		for (i = 0; (chnum[i] = fgetc(fp)) != EOF; ++i)
			;
		chnum[i] = '\0';
		fclose(fp);
		return StrToNum(chnum);
	}
	fclose(fp);
	return EOF;
}
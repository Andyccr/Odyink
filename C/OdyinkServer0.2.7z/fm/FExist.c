#include <stdio.h>

int FExist(char *fPath)
{
	FILE *fp = NULL;
	fp = fopen(fPath,"r");
	//NULL = 0
	if (fp == NULL)
		return 0;
	else
		return 1;
	fclose(fp);
}
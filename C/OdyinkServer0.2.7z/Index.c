#include <stdio.h>
#include <ctype.h>
#include "include/def.h"

int Index()
{
	int docID;
	char stop;
	char docIP[10];
	char lnk[32];

	Clear();

	ViewText("./odydata/doclist.ini");
	printf("\n");
	printf("\n");
	printf("[I]mport   [D]elte\n");
	printf("[S]etting  [E]xit\n");
	printf("\n");
	printf("ID:");
	scanf("%s",docIP);
	if (!isdigit(docIP[0]))
	{
		if (docIP[0] == 'I') Import();
		if (docIP[0] == 'D');
		if (docIP[0] == 'S');
		if (docIP[0] == 'E')
			return 0;
		printf("Input Error\n");
		return 1;
	}
	Clear();
	docID = StrToNum(docIP);
	sprintf(lnk,"./odydata/doc/%d.%s",docID,ReadDocType(docID));
	ViewText(lnk);
	printf("\"Enter\" return to the index\n");
	stop = getchar();
	stop = getchar();
	Clear();
	return 1; // Make it can loop
}

#include <stdio.h>
#include <string.h>
#include "include/def.h"

void Import()
{
	char filePath[256];
	char docTitle[70];
	char docPath[300];
	char fileType[4];
	char typeList[12];
	char titleList[80];
	int newNum;
	int newID;

	int state = 1;
	while (state)
	{
		Clear();

		// Input file path
		printf("\"q\" return to the index\n");
		printf("\n");
		printf("Doc path:");
		fgets(filePath, 256, stdin);
		strcpy(filePath, CRLFTo0(filePath));
		if (filePath[0] == 'q')
			break;
		if (!FExist(filePath))
		{
			printf("File does not exist\n");
			GenSleep(2);
			continue;
		}
		// Input Doc title
		printf("Doc title:");
		fgets(docTitle, 70, stdin);
		strcpy(docTitle, CRLFTo0(docTitle));
		if (filePath[0] == 'q')
			break;
		//Get file Type
		strcpy(fileType, GetType(filePath));
		// GetnewID
		newID = ReadNum("./odydata/docallnum.ini") + 1;
		if (!newID)
		{
			printf("ReadNum error");
			continue;
		}
		// GetnewNum
		newNum = ReadNum("./odydata/docnum.ini") + 1;
		if (!newNum)
		{
			printf("ReadNum error");
			continue;
		}

		//
		FOverWrite("./odydata/docallnum.ini", NumToStr(newID));
		//
		FOverWrite("./odydata/docnum.ini", NumToStr(newNum));
		//
		sprintf(typeList,"%s %s ", Fill(NumToStr(newID), 6, '0'), fileType);
		FAddWrite("./odydata/doctype.ini", typeList);
		//
		sprintf(titleList,"%d.%s\r\n", newID, docTitle);
		FAddWrite("./odydata/doclist.ini", titleList);
		//
		sprintf(docPath,"./odydata/doc/%s.%s", NumToStr(newID),fileType);
		FCopy(filePath,docPath);
	}
}

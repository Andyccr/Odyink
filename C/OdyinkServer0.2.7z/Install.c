#include <stdio.h>
#include <stdlib.h>
#include "include/def.h"

void Install()
{
	// Install Odyink Server
	printf("Instailling Odyink Server...\n");
	//system("mkdir odydata");
	if (OSNUM)
		system("mkdir odydata\\doc nul 2> nul");
	else
		system("mkdir -p odydata/doc");
	FOverWrite("./odydata/odyins.ini","Odyink Server is install\n");
	FOverWrite("./odydata/docnum.ini","1");
	FOverWrite("./odydata/docallnum.ini","0");
	FOverWrite("./odydata/doclist.ini","0.你好 Odyink\n");
	// It have a space after type
	FOverWrite("./odydata/doctype.ini","000000 txt "); 
	FOverWrite("./odydata/doc/0.txt","Hello this is Odyink\n");
	FAddWrite("./odydata/doc/0.txt","\n");
	FAddWrite("./odydata/doc/0.txt","Odyink is make by smgdream & Andyccr\n");
	printf("Enter to finish install\n");
	getchar();
}
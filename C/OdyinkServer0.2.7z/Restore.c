#include <stdlib.h>
#include "include/def.h"

void Restore()
{
	if (OSNUM)
		system("chcp 936");
	Clear();
}
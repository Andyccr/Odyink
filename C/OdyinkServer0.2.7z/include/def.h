#define _CRT_SECURE_NO_WARNINGS

// OSType lowercase
#define OSTYPE windows
// Windows = 1 Linux = 0
#define OSNUM 1

void Init();
void Install();
int Index();
void Import();
void Restore();


//OS Commands
	void Clear();
	void GenSleep(int second);
	void ViewText(char *fPath);
//

// Files Manipulation
	int FExist(char *fPath);
	int FCopy (char *source,char *target);
	void FOverWrite(char *fPath,char *text);
	void FAddWrite(char *fPath,char *text);
	char *ReadDocType(int docID);
	int ReadNum(char *fPath);
//

// Process
	int StrToNum(char numStr[]);
	char *NumToStr(int number);
	char *CRLFTo0(char string[]);
	char *WinPath(char *fPath);
	char *GetType(char *fPath);
	char *ReverStr(char string[]);
	char *Fill(char *string, int filSiz, char filChr);
//

//Other
//

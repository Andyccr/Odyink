#include <stdlib.h>
#include "include/def.h"

void Init()
{
	if (OSNUM)
		system("chcp 65001");
	Clear();
}
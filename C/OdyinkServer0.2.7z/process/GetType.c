#include <stdio.h>
#include <string.h>

char *GetType(char *fPath)
{
	char *start;
	static char type[5];
	start = strrchr(fPath, '.');
	sprintf(type, "%s", start);
	return &type[1];
}
int StrToNum(char numStr[])
{
	int i,number = 0;
	for (i = 0;numStr[i] >= '0' && numStr[i] <= '9';i++)
		number = 10 * number + (numStr[i] - '0');
	return number;
}
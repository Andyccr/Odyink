#include <string.h>

char *ReverStr(char *string)
{
	char temp;
	static char tmpStr[256];
	int siz;
	strcpy(tmpStr,string);
	for (siz = 0; tmpStr[siz] != '\0'; ++siz);
	for (int h = 0, l = --siz; h != l && h != l + 1; ++h, --l)
	{
		temp = tmpStr[l];
		tmpStr[l] = tmpStr[h];
		tmpStr[h] = temp;
	}
	return tmpStr;
}

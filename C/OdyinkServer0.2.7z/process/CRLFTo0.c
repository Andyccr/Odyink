#include <string.h>

char *CRLFTo0(char string[])
{
	static char strtmp[256];
	strcpy(strtmp,string);
	for (int i = 0;strtmp[i] != '\0';++i)
	{
		if (strtmp[i] == '\r' || strtmp[i] == '\n')
			strtmp[i] = '\0';
	}
	return strtmp;
}

#include <string.h>

char *WinPath(char *fPath)
{
		static char tmpePath[256];
		strcpy(tmpePath,fPath);
		for (int i = 0;tmpePath[i] !='\0';++i)
		{
			if (tmpePath[i] =='/')
				tmpePath[i] = '\\';
		}
		return tmpePath;
}
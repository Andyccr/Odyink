#include <string.h>

#include "../include/def.h" 
//#include "ReverStr.c"

char *NumToStr(int number)
{
	static char numStr[11];
	if (number != 0)
		for (int i = 0; number != 0; ++i)
		{
			numStr[i] = number % 10 + '0';
			number /= 10;
		}
	else
		numStr[0] = '0';
	strcpy(numStr, ReverStr(numStr));
	return numStr;
}

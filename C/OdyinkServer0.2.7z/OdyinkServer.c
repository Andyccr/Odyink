#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "include/def.h"

//#include "include/debug.h"


int main()
{
	char stop;

	Init();

	printf("Odyink Server\n");
	if (FExist("./odydata/odyins.ini"))
		printf("Odyink Server is installed\n");
	else
		Install();
	Clear();

	while (Index());

	stop = getchar();
	stop = getchar();

	Restore();
	return 0;
}
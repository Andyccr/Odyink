#include <stdio.h>
#include <stdlib.h>
#include "../include/def.h"

void ViewText(char *fPath)
{
	char command[64];
	if (OSNUM)
	{
		sprintf(command,"type %s",WinPath(fPath));
		system(command);
	}
	else
	{
		sprintf(command,"cat %s",fPath);
		system(command);
	}
	printf("\n");
}

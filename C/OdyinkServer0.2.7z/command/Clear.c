#include <stdlib.h>
#include "../include/def.h"

void Clear()
{
	if (OSNUM)
		system("cls");
	else
		system("clear");
}
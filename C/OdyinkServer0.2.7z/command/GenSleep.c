#include "../include/def.h"

#if OSNUM
	#include <windows.h>
#else 
	#include <unistd.h>
#endif


void GenSleep(int second)
{
	if (OSNUM)
		Sleep(second * 1000);
	else
	{
		unsigned int sleep(unsigned int seconds);
		sleep(second);
	}
}
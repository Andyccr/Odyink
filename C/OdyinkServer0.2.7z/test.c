#include <stdio.h>
#include <string.h>
#include "include/def.h"

//#include "process/CRLFTo0.c"
#include "process/NumToStr.c"

int main()
{
	int number;
	char input[256];
	char output[256];
	//fgets(input,256,stdin);
	scanf("%d",&number);
	strcpy(output,NumToStr(number));
	//
	printf("num:%s\n", output);
	//
	return 0;
}
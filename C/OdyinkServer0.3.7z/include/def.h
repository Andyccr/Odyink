#define _CRT_SECURE_NO_WARNINGS

// OSType lowercase
#define OSTYPE windows
// Windows = 1 Linux = 0
#define OSNUM 1

void cmdInit();
void install();
int docIndex();
void importDoc();
void deleteDoc();
void cmdRestore();


//OS Commands
	void clear();
	void genSleep(int second);
	void viewText(char *fPath);
//

// Files Manipulation
	int fExist(char *fPath);
	int fCopy (char *source,char *target);
	void fNewOp(char *fPath,char *text);
	void fAddOp(char *fPath,char *text);
	void typeConv(int docId, char *type);
	void indexConv(int docId, char *newIndex);
	void viewIndex(char *fPath);
	char *readType(int docId);
	int fgeti(char *fPath);
//

// Process
	int stoi(char numStr[]);
	char *itos(int number);
	char *crlfTo0(char string[]);
	char *unixPath(char *fPath);
	char *winPath(char *fPath);
	char *getType(char *fPath);
	char *reverse(char string[]);
	char *fill(char *string, int filSiz, char filChr);
//

//Other
//

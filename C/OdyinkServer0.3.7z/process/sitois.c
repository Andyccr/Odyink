#define strcopy(T, S) for (int i = 0; *(T + i) = *(S + i); ++i)


int stoi(char numStr[])
{
	int i,number = 0;
	for (i = 0;numStr[i] >= '0' && numStr[i] <= '9';i++)
		number = 10 * number + (numStr[i] - '0');
	return number;
}


char *itos(int number)
{
	static char numStr[11];
	char *reverse(char *string);
	if (number != 0)
		for (int i = 0; number != 0; ++i)
		{
			numStr[i] = number % 10 + '0';
			number /= 10;
		}
	else
		numStr[0] = '0';
	strcopy(numStr, reverse(numStr));
	return numStr;
}


char *reverse(char *string)
{
	char temp;
	static char tmpStr[256];
	int siz;
	strcopy(tmpStr,string);
	for (siz = 0; tmpStr[siz] != '\0'; ++siz);
	for (int h = 0, l = --siz; h != l && h != l + 1; ++h, --l)
	{
		temp = tmpStr[l];
		tmpStr[l] = tmpStr[h];
		tmpStr[h] = temp;
	}
	return tmpStr;
}
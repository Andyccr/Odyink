#define strcopy(T, S) for (int i = 0; *(T + i) = *(S + i); ++i)


char *winPath(char *fPath)
{
		static char tmpePath[32];
		//for (int i = 0; *(tmpePath + i) = *(fPath + i); ++i);
		strcopy(tmpePath,fPath);
		for (int i = 0;tmpePath[i] !='\0';++i)
		{
			if (tmpePath[i] =='/')
				tmpePath[i] = '\\';
		}
		return tmpePath;
}


char *unixPath(char *fPath)
{
		static char tmpePath[32];
		//for (int i = 0; *(tmpePath + i) = *(fPath + i); ++i);
		strcopy(tmpePath,fPath);
		for (int i = 0;tmpePath[i] !='\0';++i)
		{
			if (tmpePath[i] =='\\')
				tmpePath[i] = '/';
		}
		return tmpePath;
}
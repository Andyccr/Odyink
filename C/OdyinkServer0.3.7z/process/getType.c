#include <stdio.h>
#include <string.h>

char *getType(char *fPath)
{
	char *start;
	static char type[5];
	start = strrchr(fPath, '.');
	sprintf(type, "%s", start);
	return &type[1];
}
#define NULL ((void *)0)

char *fill(char *string, int filSiz, char filChr)
{
	int si = 0; // String index
	int ti = 0; // tmpStr index
	int strSiz, filSign;
	static char tmpStr[256];
	// Get string size
	for (strSiz = 0; string[strSiz] != '\0'; ++strSiz)
		;
	// Compute filSiz absolute & set fill sign
	filSign = 1;
	if (filSiz < 0)
	{
		filSiz *= -1;
		filSign = -1;
	}
	// Start fill
	if (filSiz < strSiz)
		return NULL;
	if (filSiz == strSiz)
		return string;
	// If filStr > strSiz
	filSiz -= strSiz;
	// High fill (filSign == 1)
	if (filSign == 1)
		for (ti = 0; filSiz + strSiz > 0; ++ti)
		{
			if (filSiz > 0)
			{
				tmpStr[ti] = filChr;
				--filSiz;
				continue;
			}
			if (filSiz == 0)
				if (strSiz > 0)
				{
					tmpStr[ti] = string[si++];
					--strSiz;
				}
		}
	// Low fill (filSign == -1)
	if (filSign == -1)
		for (ti = 0; filSiz + strSiz > 0; ++ti)
		{
			if (strSiz > 0)
			{
				tmpStr[ti] = string[si++];
				--strSiz;
				continue;
			}
			if (strSiz == 0)
				if (filSiz > 0)
				{
					tmpStr[ti] = filChr;
					--filSiz;
				}
		}
	tmpStr[ti] = '\0';
	return tmpStr;
}
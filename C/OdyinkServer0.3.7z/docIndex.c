#include <stdio.h>
#include <ctype.h>
#include "include/def.h"

int docIndex()
{
	int docId;
	char stop;
	char docIp[10];
	char lnk[32];

	int state = 1;
	while (state)
	{
		clear();

		viewIndex("./odydata/docindex.ini");
		printf("\n");
		printf("\n");
		printf("[I]mport   [D]elte\n");
		printf("[S]etting  [E]xit\n");
		printf("\n");
		printf("ID:");
		scanf("%s",docIp);
		if (!isdigit(docIp[0]))
		{
			docIp[0] = toupper(docIp[0]);
			if (docIp[0] == 'I')
			{
				importDoc();
				continue;
			}
			if (docIp[0] == 'D')
			{
				deleteDoc();
				continue;
			}
			if (docIp[0] == 'S');
			if (docIp[0] == 'E')
				return 0;
			printf("Input Error\n");
			genSleep(2);
			continue;
		}
		clear();
		docId = stoi(docIp);
		sprintf(lnk,"./odydata/doc/%d.%s",docId,readType(docId));
		viewText(lnk);
		printf("\"Enter\" return to the index\n");
		stop = getchar();
		stop = getchar();
		clear();
	}
}

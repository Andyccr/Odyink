#include <stdlib.h>


void cmdInit()
{
	system("chcp 65001");
}


void cmdRestore()
{
	system("chcp 936");
}
#include <stdio.h>
#include <stdlib.h>
#include "include/def.h"

void install()
{
	// Install Odyink Server
	printf("Instailling Odyink Server...\n");
	char index[80];
	// Make dir odydata
	if (OSNUM)
		system("mkdir odydata\\doc nul 2> nul");
	else
		system("mkdir -p odydata/doc");
	fNewOp("./odydata/odyins.ini", "Odyink Server is install\n");
	fNewOp("./odydata/docnum.ini", "1");
	fNewOp("./odydata/allocid.ini", "0");
	sprintf(index, "%s%c", fill("0.Hello Odyink", -79, '\v'), '\t');
	fNewOp("./odydata/docindex.ini", index);
	// It have a space after type
	fNewOp("./odydata/doctype.ini", "000000 txt\t");
	fNewOp("./odydata/doc/0.txt", "Hello this is Odyink\n");
	fAddOp("./odydata/doc/0.txt", "\n");
	fAddOp("./odydata/doc/0.txt", "Odyink is make by smgdream & Andyccr\n");
	printf("Enter to finish install\n");
	getchar();
}
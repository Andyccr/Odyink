#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "include/def.h"

void deleteDoc()
{
	int state = 1;
	while (state)
	{
		// Init
		int docId = 0;
		char delYN = 'n';
		char delDoc[32];
		clear();

		// Show the index
		viewIndex("./odydata/docindex.ini");

		// Enter the ID of doc will be delete
		printf("\"-1\" return to the index\n");
		printf("\n");
		printf("DocID:");
		scanf("%d", &docId);
		if (docId == -1)
			break;
		sprintf(delDoc, "./odydata/doc/%d.%s", docId, readType(docId));
		if (!fExist(delDoc))
		{
			if (!strcmp(readType(docId), "nul"))
			{
				printf("The doc has been deleted\n");
				genSleep(2);
				continue;
			}
			else
			{
				printf("Doc does not exist\n");
				genSleep(2);
				continue;
			}
		}

		// Sure to delete
		printf("Sure to delete (y/n):");
		getchar();
		delYN = getchar();
		if (toupper(delYN) != 'Y')
			continue;

		// Start del
		fNewOp("./odydata/docnum.ini", itos(fgeti("./odydata/docnum.ini") - 1));
		typeConv(docId, "nul");
		indexConv(docId, fill("\v", 80, '\v'));
		remove(delDoc);
		printf("Finish\n");
		genSleep(2);
	}
}
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "include/def.h"

//#include "include/debug.h"


int main()
{
	char stop;

	cmdInit();
	clear();

	printf("Odyink Server\n");
	if (fExist("./odydata/odyins.ini"))
		printf("Odyink Server is installed\n");
	else
		install();
	clear();

	docIndex();

	stop = getchar();
	stop = getchar();

	cmdRestore();
	clear();
	return 0;
}
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "include/def.h"

void importDoc()
{
	int state = 1;
	while (state)
	{
		char filePath[256];
		char docTitle[72];
		char docPath[32];
		char fileType[4];
		char typeIndex[12];
		char titleIndex[80];
		int newNum;
		int newId;
		
		clear();

		// Input file path
		printf("\"q\" return to the index\n");
		printf("\n");
		printf("Doc path:");
		fgets(filePath, 256, stdin);
		strcpy(filePath, unixPath(crlfTo0(filePath)));
		if (toupper(filePath[0]) == 'Q')
			break;
		if (!fExist(filePath))
		{
			printf("File does not exist\n");
			genSleep(2);
			continue;
		}

		// Input Doc title
		printf("Doc title:");
		fgets(docTitle, 70, stdin);
		strcpy(docTitle, crlfTo0(docTitle));
		if (toupper(docTitle[0]) == 'Q')
			break;

		//Get file Type
		strcpy(fileType, getType(filePath));
		// GetnewID
		newId = fgeti("./odydata/allocid.ini") + 1;
		if (!newId)
		{
			printf("fgeti error");
			continue;
		}
		// GetnewNum
		newNum = fgeti("./odydata/docnum.ini") + 1;
		if (!newNum)
		{
			printf("fgeti error");
			continue;
		}

		// Start import the doc
		// Write the docID
		fNewOp("./odydata/allocid.ini", itos(newId));
		// Write the number of doc
		fNewOp("./odydata/docnum.ini", itos(newNum));
		// Write the doc type
		sprintf(typeIndex,"%s %s\t", fill(itos(newId), 6, '0'), fileType);
		fAddOp("./odydata/doctype.ini", typeIndex);
		// Write the index of title
		sprintf(titleIndex,"%d.%s\t", newId, fill(docTitle, -72, '\v'));
		fAddOp("./odydata/docindex.ini", titleIndex);
		// Copy the doc
		sprintf(docPath,"./odydata/doc/%s.%s", itos(newId),fileType);
		fCopy(filePath,docPath);
		//
		genSleep(2);
		printf("Finish\n");
	}
}

#include <stdio.h>

void indexConv(int docId, char *newIndex)
{
	FILE *fp = NULL;
	fp = fopen("./odydata/docindex.ini", "r+");
	if (fp != NULL)
	{
		// Please viev the Dev Document
		fseek(fp, 80 * docId, SEEK_SET);
		ftell(fp);
		fputs(newIndex, fp);
		fclose(fp);
	}
	fclose(fp);
}
#include <stdio.h>

void viewIndex(char *fPath)
{
	char ch = '\0';
	FILE *fp = NULL;
	fp = fopen(fPath, "r");
	if (fp != NULL)
	{
		// Please viev the Dev Document
		while ((ch = fgetc(fp)) != EOF)
		{
			if (ch == '\v')
				continue;
			if (ch == '\t')
			{
				printf("\n");
				continue;
			}
			printf("%c", ch);
		}
		printf("\n");
		fclose(fp);
	}
	fclose(fp);
}
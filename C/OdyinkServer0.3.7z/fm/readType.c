#include <stdio.h>

char *readType(int docId)
{
	static char type[4];
	FILE *fp = NULL;
	fp = fopen("./odydata/doctype.ini", "r");
	if (fp != NULL)
	{
		// Please viev the Dev Document
		fseek(fp, 11 * docId + 7, SEEK_SET);
		fgets(type, 3 + 1, fp);
		fclose(fp);
		return type;
	}
	fclose(fp);
	return NULL;
}

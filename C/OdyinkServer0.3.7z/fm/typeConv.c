#include <stdio.h>

void typeConv(int docId, char *type)
{
	FILE *fp = NULL;
	fp = fopen("./odydata/doctype.ini", "r+");
	if (fp != NULL)
	{
		// Please viev the Dev Document
		fseek(fp, 11 * docId + 7, SEEK_SET);
		fputs(type, fp);
		fclose(fp);
	}
	fclose(fp);
}
// OS type
// Windows = 1 Linux = 0
	#define OSNUM 1
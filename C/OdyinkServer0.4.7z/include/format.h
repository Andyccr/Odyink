// #include "../include/format.h"

#define ID_LEN 7
#define TYPE_LEN 12
#define INDEX_LEN 81

#define TYPE_OFFSET 8

#define ID_MAX 9999999
#define TITLE_MAX_LEN 72
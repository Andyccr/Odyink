#include "ostype.h"
#define _CRT_SECURE_NO_WARNINGS


void install(void);
void docIndex(void);
void importDoc(void);
void deleteDoc(void);


// Open Document
	int openDoc(int id);
//

// User options
	void options(void);
	void help(void);
	void about(void);
	void reinstall(void);
	void uninstall(void);
//

//OS Commands
	void clear(void);
	void cmdInit(void);
	void cmdRestore(void);
	void delAllDoc(void);
	void genSleep(int second);
	void viewText(char *fPath);
//

// Files Manipulation
	int fExist(char *fPath);
	void fCopy (char *source,char *target);
	void fNewOp(char *fPath,char *text);
	void fAddOp(char *fPath,char *text);
	void typeCov(int docId, char *type);
	void indexCov(int docId, char *index);
	void viewIndex(char *fPath);
	char *readType(int docId);
	int search(char *keyWord);
	int fgeti(char *fPath);
	int backDoc(int id);
	int nextDoc(int id);
//

// Process
	char *getUTC(void);
	int stoi(char *numStr);
	char *itos(int number);
	char *unixPath(char *fPath);
	char *winPath(char *fPath);
	char *getType(char *fPath);
	char *crlfTo0(char *string);
	char *reverse(char *string);
	char *fill(char *string, int filSiz, char filChr);
//

//Other
//

#define strcopy(T, S) for (int i = 0; *(T + i) = *(S + i); ++i)
#define arrclean(STR, SIZE) \
{\
	int i = 0;\
	int size = SIZE;\
	for (char *str = STR; i < size; ++i) *(str + i) = 0\
		;\
}


char *winPath(char *fPath)
{
	static char tmpePath[32];
	arrclean(tmpePath, 32);
	strcopy(tmpePath,fPath);
	for (int i = 0;tmpePath[i] !='\0';++i)
	{
		if (tmpePath[i] =='/')
			tmpePath[i] = '\\';
	}
	return tmpePath;
}


char *unixPath(char *fPath)
{
	static char tmpePath[32];
	arrclean(tmpePath, 32);
	strcopy(tmpePath,fPath);
	for (int i = 0;tmpePath[i] !='\0';++i)
	{
		if (tmpePath[i] =='\\')
			tmpePath[i] = '/';
	}
	return tmpePath;
}
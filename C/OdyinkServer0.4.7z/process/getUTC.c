#include <stdio.h>
#include <time.h>
#define UTC 0
#define arrclean(STR, SIZE) \
{\
	int i = 0;\
	int size = SIZE;\
	for (char *str = STR; i < size; ++i) *(str + i) = 0\
		;\
}
#define timefill(STR, TIME) \
	if (TIME < 10) sprintf(STR, "0%d", TIME);\
	else sprintf(STR, "%d", TIME);
//


char *getUTC(void)
{
	//
	time_t tsp; // timestamp
	struct tm *timep; // timePointer
	static char timestr[28];
	arrclean(timestr, 28);
	//
	time(&tsp);
	tsp += UTC * 3600;
	timep = gmtime(&tsp);
	//
	{
		char mon[3] = "\0\0";
		char mday[3] = "\0\0";
		char hour[3] = "\0\0";
		char min[3] = "\0\0";
		char sec[3] = "\0\0";
		timefill(mon, timep->tm_mon + 1);
		timefill(mday, timep->tm_mday);
		timefill(hour, timep->tm_hour);
		timefill(min, timep->tm_min);
		timefill(sec, timep->tm_sec);

		sprintf(timestr, "%d-%s-%s %s:%s:%s (UTC)\0"
			, timep->tm_year + 1900, mon, mday
			, hour, min, sec
		);
	}
	return timestr;
}
#include <stdio.h>
#include <string.h>
#define arrclean(STR, SIZE) \
{\
	int i = 0;\
	int size = SIZE;\
	for (char *str = STR; i < size; ++i) *(str + i) = 0\
		;\
}

char *getType(char *fPath)
{
	char *start;
	static char type[5];
	arrclean(type, 5);
	start = strrchr(fPath, '.');
	sprintf(type, "%s", start);
	return type + 1;
}
#include <string.h>
#define arrclean(STR, SIZE) \
{\
	int i = 0;\
	int size = SIZE;\
	for (char *str = STR; i < size; ++i) *(str + i) = 0\
		;\
}

char *crlfTo0(char *string)
{
	static char tmpStr[256];
	arrclean(tmpStr, 256);
	strcpy(tmpStr,string);
	for (int i = 0;tmpStr[i] != '\0';++i)
	{
		if (tmpStr[i] == '\r' || tmpStr[i] == '\n')
			tmpStr[i] = '\0';
	}
	return tmpStr;
}
#define arrclean(STR, SIZE) \
{\
	int i = 0;\
	int size = SIZE;\
	for (char *str = STR; i < size; ++i) *(str + i) = 0\
		;\
}
#define strcopy(T, S) {\
	int i = 0;\
	for (char *t = T, *s = S; *(t + i) = *(s + i); ++i)\
		;\
}



int stoi(char *numStr)
{
	int i, number = 0;
	for (i = 0; numStr[i] >= '0' && numStr[i] <= '9'; i++)
		number = 10 * number + (numStr[i] - '0');
	return number;
}


char *itos(int number)
{
	static char numStr[12];
	arrclean(numStr, 12);
	char *reverse(char *string);
	if (number != 0)
		for (int i = 0; number != 0; ++i)
		{
			numStr[i] = number % 10 + '0';
			number /= 10;
		}
	else
		numStr[0] = '0';
	numStr[11] = '\0';
	strcopy(numStr, reverse(numStr));
	return numStr;
}


char *reverse(char *string)
{
	int siz;
	char temp;
	static char tmpStr[256];
	arrclean(tmpStr, 256);
	strcopy(tmpStr, string);
	for (siz = 0; tmpStr[siz] != '\0'; ++siz)
		;
	for (int h = 0, l = --siz; h != l && h != l + 1; ++h, --l)
	{
		temp = tmpStr[l];
		tmpStr[l] = tmpStr[h];
		tmpStr[h] = temp;
	}
	return tmpStr;
}
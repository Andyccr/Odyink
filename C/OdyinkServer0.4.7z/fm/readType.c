#include <stdio.h>
#include "../include/format.h"

#define arrclean(STR, SIZE) \
{\
	int i = 0;\
	int size = SIZE;\
	for (char *str = STR; i < size; ++i) *(str + i) = 0\
		;\
}

char *readType(int docId)
{
	static char type[4];
	arrclean(type, 4);
	FILE *fp = NULL;
	fp = fopen("./odydata/doctype.ini", "r");
	if (fp != NULL)
	{
		// Please view the Dev Document
		fseek(fp, TYPE_LEN * docId + TYPE_OFFSET, SEEK_SET);
		fgets(type, 3 + 1, fp);
		for (int i = 0; i < 3; ++i)
			type[i] == '0' ? type[i] = '\0' : 0 ;
		fclose(fp);
		return type;
	}
	fclose(fp);
	return NULL;
}

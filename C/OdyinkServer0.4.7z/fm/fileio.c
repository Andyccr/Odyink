#include <stdio.h>


int fExist(char *fPath)
{
	FILE *fp = NULL;
	fp = fopen(fPath,"r");
	if (fp == NULL)
	{
		fclose(fp);
		return 0;
	}
	else
	{
		fclose(fp);
		return 1;
	}
		
}


void fNewOp(char *fPath,char *text)
{
	FILE *fp = NULL;
	fp = fopen(fPath,"w+");
	fputs(text,fp);
	fclose(fp);
	return;
}


void fAddOp(char *fPath,char *text)
{
	FILE *fp = NULL;
	fp = fopen(fPath,"a+");
	fputs((char *)text,fp);
	fclose(fp);
	return;
}


void fCopy (char *source,char *target)
{
	char tfs; // Temp file stream
	int n;
	//
	FILE *fpSource;
	fpSource = fopen(source,"rb");
	//
	FILE *fpTarget;
		fpTarget = fopen(target,"wb+");
	// if use the feof() it will write the last byte again
	while (fread(&tfs,1,1,fpSource))
		fwrite(&tfs,1,1,fpTarget);
	//printf("Finish\n");
	//
	fclose(fpTarget);
	fclose(fpSource);
	return;
}


int fgeti(char *fPath)
{
	int i;
	int number = 0;
	char strnum[12];
	FILE *fp = NULL;
	fp = fopen(fPath, "r");
	if (fp != NULL)
	{
		// Please viev the Dev Document
		/* Expr2 will set last element = EOF
		So I should deal with it*/
		for (i = 0; (strnum[i] = fgetc(fp)) != EOF; ++i)
			;
		strnum[i] = '\0';
		fclose(fp);
		for (i = 0;strnum[i] >= '0' && strnum[i] <= '9';i++)
		number = 10 * number + (strnum[i] - '0');
		return number;
	}
	fclose(fp);
	return 0;
}
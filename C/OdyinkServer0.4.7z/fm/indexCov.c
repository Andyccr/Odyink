#include <stdio.h>

void indexCov(int docId, char *index)
{
	FILE *fp = NULL;
	fp = fopen("./odydata/docindex.ini", "r+");
	if (fp != NULL)
	{
		// Please viev the Dev Document
		fseek(fp, 81 * docId, SEEK_SET);
		ftell(fp);
		fputs(index, fp);
		fclose(fp);
	}
	fclose(fp);
	return;
}
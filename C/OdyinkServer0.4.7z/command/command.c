#include <stdio.h>
#include <stdlib.h>
#include "../include/def.h"

#if OSNUM
	#include <windows.h>
#else 
	#include <unistd.h>
#endif


void clear(void)
{
	if (OSNUM)
		system("cls");
	else
		printf("\x1b[2J");
	return;
}


void viewText(char *fPath)
{
	char command[64];
	if (OSNUM)
	{
		sprintf(command,"type %s",winPath(fPath));
		system(command);
	}
	else
	{
		sprintf(command,"cat %s",fPath);
		system(command);
	}
	printf("\n");
	return;
}


void genSleep(int second)
{
	if (OSNUM)
		Sleep(second * 1000);
	else
	{
		unsigned int sleep(unsigned int seconds);
		sleep(second);
	}
	return;
}
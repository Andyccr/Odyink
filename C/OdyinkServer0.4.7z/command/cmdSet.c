#include <stdlib.h>


void cmdInit(void)
{
	system("title Odyink Server");
	system("chcp 65001");
	return;
}


void cmdRestore(void)
{
	system("title cmd");
	system("chcp 936");
	return;
}
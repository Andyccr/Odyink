#include "../include/def.h"

void reinstall(void)
{
	delAllDoc();
	install();
	return;
}
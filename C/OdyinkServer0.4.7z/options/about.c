#include <stdio.h>
#include "../include/def.h"

void about(void)
{
	clear();
	printf("                About Odyink\n");
	printf("\n");
	printf("           Odyink make by smgdream\n");
	printf("         Odyink debugged by smgdream\n");
	printf("      Odyink test by smgdream & Andyccr\n");
	printf("     Early Odyink written in Batch script\n");
	printf("Github: https://github.com/smgdream/OdyinkCode\n");
	printf("           Website: https://ody.ink/\n");

	printf("\n\nEnter to return\n");
	getchar();
	clear();
}
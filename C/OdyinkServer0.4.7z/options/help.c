#include <stdio.h>
#include "../include/def.h"

void help(void)
{
	clear();
	printf("         Help\n");
	printf("\n");
	printf("https://ody.ink/help/*\n");
	printf("\n\nEnter to return\n");
	getchar();
	clear();
}
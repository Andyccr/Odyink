#include <stdlib.h>
#include "../include/def.h"

void uninstall(void)
{
	delAllDoc();
	exit(0);
}
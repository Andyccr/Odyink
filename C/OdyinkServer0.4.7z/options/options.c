#include <stdio.h>
#include <ctype.h>
#include "../include/def.h"

void options(void)
{
	while (1)
	{
		clear();
		char ip = '\0';
		printf("\n[H]elp\n");
		printf("\n[A]bout\n");
		printf("\n[R]einstall\n");
		printf("\n[U]ninstall\n");
		printf("\n[B]ack\n");
		printf("\n\ninput: ");
		scanf("%c", &ip);
		getchar();
		ip = toupper(ip);
		if (ip == 'H')
			help();
		else if (ip == 'A')
			about();
		else if (ip == 'R')
		{
			reinstall();
			return;
		}
		else if (ip == 'U')
			uninstall();
		else if (ip == 'B')
			return;
		else
		{
			printf("Input Error\n");
			genSleep(2);
		}
	}
}
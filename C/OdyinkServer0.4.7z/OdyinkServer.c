#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "include/def.h"

//#include "include/debug.h"

// version 0.4
// 2022-01-25 21:50:30 (UTC+8)

int main()
{
	cmdInit();
	clear();

	printf("Odyink Server\n");
	if (fExist("./odydata/odyink.log"))
		printf("Odyink Server is installed\n");
	else
		install();
	clear();

	docIndex();

	cmdRestore();
	clear();
	return 0;
}
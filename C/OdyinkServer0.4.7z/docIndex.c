#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "include/def.h"
#include "include/format.h"

void docIndex(void)
{
	int findSign = 0;
	char docIp[10];

	while (1)
	{
		if (findSign != 1)
			clear();
		if (findSign != 1)
			viewIndex("./odydata/docindex.ini");
		if (findSign == 1)
			printf("\n[B]ack to index");
		findSign = 0;
		//
		printf("\n\n[I]mport   [S]earch  [D]elte\n");
		printf("[O]ptions            [E]xit\n");
		printf("\n");
		printf("ID:");
		scanf("%s", docIp);
		if (!isdigit(docIp[0]))
		{
			getchar();
			docIp[0] = toupper(docIp[0]);
			if (docIp[0] == 'I')
				importDoc();
			else if (docIp[0] == 'D')
				deleteDoc();
			else if (docIp[0] == 'S')
			{
				char keyWord[TITLE_MAX_LEN];
				printf("\nKeyword: ");
				fgets(keyWord, TITLE_MAX_LEN, stdin);
				clear();
				strcpy(keyWord, crlfTo0(keyWord));
				printf("\nfound %d item\n", search(keyWord));
				findSign = 1;
			}
			else if (docIp[0] == 'O')
				options();
			else if (docIp[0] == 'B')
				continue;
			else if (docIp[0] == 'E')
				return;
			else
			{
				printf("Input Error\n");
				genSleep(2);
			}
			continue;
		}
		getchar();
		openDoc(stoi(docIp));
		clear();
	}
}

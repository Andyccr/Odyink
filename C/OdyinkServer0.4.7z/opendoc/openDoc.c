#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "../include/def.h"

#define getch(VAR) while ((VAR = getc(stdin)) != '\n');VAR = getc(stdin)


int openDoc(int id)
{
	while (1)
	{
		clear();
		char ip = '0';
		char *docType;
		char docPath[32];
		sprintf(docPath, "./odydata/doc/%d.%s\0", id, docType = readType(id));
		if (!strcmp(docType, "txt"))
			viewText(docPath);
		else if (!strcmp(docType, "sh"))
			;
		else if (!strcmp(docType, "bat"))
			;
		else if (!strcmp(docType, "py"))
			;
		else if (!strcmp(docType, "c"))
			;
		else if (!strcmp(docType, "cpp"))
			;
		else if (!strcmp(docType, "nul"))
		{
			printf("The doc has been deleted\n");
			genSleep(2);
			break;
		}
		else
		{
			printf("Doc does not exist\n");
			genSleep(2);
			break;
		}
		//
		ipOpt:	
		printf("\n[N]ext    [Q]uit    [B]ack\n");
		printf("\ninput: ");
		scanf("%c", &ip);
		getchar();
		ip = toupper(ip);
		if (ip == 'N')
		{
			id = nextDoc(id);
			continue;
		}
		else if (ip == 'B')
		{
			id = backDoc(id);
			printf("%d\n", id);
			continue;
		}
		else if (ip == 'Q')
			break;
		else 
		{
			printf("Input error\n");
			goto ipOpt;
		}
	}
}